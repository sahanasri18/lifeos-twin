from datetime import date
import pytest
from pydantic import ValidationError

from app.models.infrastructure_data import InfrastructureImportRequest
from app.services.infrastructure_data import InfrastructureDataRegistry


def payload(**overrides):
    data = {
        "domain": "traffic", "dataset_name": "Chennai traffic sample",
        "provider": "Sample transport department", "source_url": "https://data.example.org/traffic",
        "license": "CC BY 4.0", "data_as_of": "2026-11-14",
        "observations": [
            {"observed_at": "2026-11-14T09:00:00+05:30", "area": "Central", "metric": "vehicle_count", "value": 1200, "unit": "vehicles/hour"},
            {"observed_at": "2026-11-14T10:00:00+05:30", "area": "Central", "metric": "average_speed", "value": 28.5, "unit": "km/h"},
        ],
    }
    data.update(overrides)
    return InfrastructureImportRequest.model_validate(data)


def test_import_keeps_provider_license_and_source_provenance():
    result = InfrastructureDataRegistry().import_dataset(payload())
    assert result["provider"] == "Sample transport department"
    assert result["license"] == "CC BY 4.0"
    assert result["source_url"] == "https://data.example.org/traffic"
    assert result["observation_count"] == 2
    assert result["quality_status"] == "basic_checks_passed"


def test_rejects_unknown_metric_and_marks_quality_review():
    request = payload(observations=[{"observed_at": "2026-11-14T09:00:00+05:30", "area": "Central", "metric": "congestion_magic", "value": 2, "unit": "units"}, {"observed_at": "2026-11-14T10:00:00+05:30", "area": "Central", "metric": "vehicle_count", "value": 10, "unit": "vehicles"}])
    result = InfrastructureDataRegistry().import_dataset(request)
    assert result["quality_status"] == "review_required"
    assert result["rejected_count"] == 1
    assert result["quality_issues"][0]["code"] == "unsupported_metric"


def test_rejects_unit_mismatch():
    request = payload(observations=[{"observed_at": "2026-11-14T09:00:00+05:30", "area": "Central", "metric": "average_speed", "value": 30, "unit": "litres"}])
    with pytest.raises(ValueError, match="No valid observations"):
        InfrastructureDataRegistry().import_dataset(request)


def test_rejects_naive_timestamp_as_quality_issue():
    request = payload(observations=[{"observed_at": "2026-11-14T09:00:00", "area": "Central", "metric": "vehicle_count", "value": 10, "unit": "vehicles/hour"}])
    with pytest.raises(ValueError, match="No valid observations"):
        InfrastructureDataRegistry().import_dataset(request)


def test_rejects_duplicate_observation():
    item = {"observed_at": "2026-11-14T09:00:00+05:30", "area": "Central", "metric": "vehicle_count", "value": 10, "unit": "vehicles/hour"}
    request = payload(observations=[item, item])
    result = InfrastructureDataRegistry().import_dataset(request)
    assert result["observation_count"] == 1
    assert result["rejected_count"] == 1
    assert result["quality_issues"][0]["code"] == "duplicate_observation"


def test_rejects_future_out_of_sanity_range_values():
    request = payload(observations=[{"observed_at": "2026-11-14T09:00:00+05:30", "area": "Central", "metric": "average_speed", "value": 999, "unit": "km/h"}])
    with pytest.raises(ValueError, match="No valid observations"):
        InfrastructureDataRegistry().import_dataset(request)


def test_registry_filters_domain_and_keeps_raw_records_out_of_list():
    registry = InfrastructureDataRegistry()
    result = registry.import_dataset(payload())
    listing = registry.list_datasets("traffic")
    assert listing["count"] == 1
    assert "observations" not in listing["datasets"][0]
    assert registry.get_dataset(result["dataset_id"])["observations"]
    assert registry.list_datasets("water")["count"] == 0


def test_request_rejects_invalid_domain_and_bad_source_url():
    with pytest.raises(ValidationError):
        payload(domain="weather")
    with pytest.raises(ValidationError):
        payload(source_url="file:///etc/passwd")
