# LifeOS Twin API

FastAPI backend for the LifeOS Twin fictional-city decision-support prototype.

## Start

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Interactive API documentation: `http://127.0.0.1:8000/docs`.

## Main API areas

| Area | Routes | Purpose |
|---|---|---|
| Health and city | `/health`, `/city` | Service status and synthetic city metadata |
| Simulation | `/simulate`, `/scenarios/explore` | Deterministic scenario and what-if calculations |
| Decision workflow | `/agents/investigate` | Plan, execute, verify and explain an investigation |
| Knowledge | `/knowledge/query` | Search the built-in synthetic planning corpus |
| Workspaces | `/auth/*`, `/workspace/*` | Authenticated user scenarios, notes and private investigations |
| Forecasting | `/forecasts/project` | Compound-growth projections from user assumptions |
| External context | `/data-sources`, `/data-sources/open-meteo/current` | Provider catalog and optional current-weather lookup |
| Infrastructure imports | `/infrastructure-data/*` | Validate and inspect user-supplied observations |
| Reports | `*.pdf` report routes | Generate scenario and investigation PDF reports |

Private workspace routes require `Authorization: Bearer <token>` obtained from `/auth/register` or `/auth/login`.

## Configuration

See `.env.example`. Before public deployment, set a unique `LIFEOS_AUTH_SECRET`, restrict `LIFEOS_CORS_ORIGINS` to known frontend origins, use HTTPS and review the security model. The default development secret and wildcard CORS setting are for local development only.

Workspace accounts, scenarios, notes and agent memories use SQLite. Infrastructure dataset imports currently use process memory and are lost when the API process restarts. They are not used in simulation calculations.

## Tests

Run from this directory:

```bash
pytest -q
```

Current result: **120 passed**. The suite does not replace live-provider checks, browser testing or a production security review.

## Method boundaries

- City baselines and simulation values are synthetic.
- Planning and task execution use deterministic rules and registered Python handlers.
- Traffic, water and electricity specialists are deterministic scoring functions, not autonomous AI agents.
- Forecasts apply user-provided compound annual growth rates; they are not trained predictions.
- Open-Meteo weather is context only and does not affect infrastructure outputs.
- Imported observations receive basic validation, not independent source verification.
