"""Request models for provenance-aware infrastructure observations."""
from datetime import date, datetime
from typing import Literal
from pydantic import BaseModel, Field, HttpUrl, field_validator


class InfrastructureObservation(BaseModel):
    observed_at: datetime
    area: str = Field(min_length=1, max_length=120)
    metric: str = Field(min_length=1, max_length=80)
    value: float
    unit: str = Field(min_length=1, max_length=30)

    @field_validator("area", "metric", "unit")
    @classmethod
    def strip_text(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be blank.")
        return value


class InfrastructureImportRequest(BaseModel):
    domain: Literal["traffic", "water", "electricity"]
    dataset_name: str = Field(min_length=3, max_length=160)
    provider: str = Field(min_length=2, max_length=120)
    source_url: HttpUrl
    license: str = Field(min_length=2, max_length=120)
    data_as_of: date
    observations: list[InfrastructureObservation] = Field(min_length=1, max_length=5000)

    @field_validator("dataset_name", "provider", "license")
    @classmethod
    def strip_metadata(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Metadata cannot be blank.")
        return value
