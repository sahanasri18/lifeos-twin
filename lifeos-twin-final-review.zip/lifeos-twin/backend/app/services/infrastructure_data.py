"""In-memory import registry for user-supplied infrastructure observations.

Imports are kept separate from the synthetic simulation and are intentionally
not treated as verified official data merely because metadata was supplied.
"""
from collections import Counter
from datetime import datetime, timezone
from math import isfinite
from uuid import uuid4
from typing import Any

from app.models.infrastructure_data import InfrastructureImportRequest

METRIC_RULES: dict[str, dict[str, Any]] = {
    "traffic": {
        "vehicle_count": {"units": {"vehicles", "vehicles/hour", "vehicles_per_hour"}, "minimum": 0, "maximum": 10_000_000},
        "average_speed": {"units": {"km/h", "kph"}, "minimum": 0, "maximum": 250},
        "travel_time": {"units": {"minutes", "min"}, "minimum": 0, "maximum": 1440},
    },
    "water": {
        "consumption": {"units": {"litres", "liters", "m3", "m³", "litres/day", "liters/day"}, "minimum": 0, "maximum": 1_000_000_000_000},
        "reservoir_level": {"units": {"percent", "%"}, "minimum": 0, "maximum": 100},
        "supply_volume": {"units": {"litres", "liters", "m3", "m³"}, "minimum": 0, "maximum": 1_000_000_000_000},
    },
    "electricity": {
        "consumption": {"units": {"kwh", "mwh", "gwh"}, "minimum": 0, "maximum": 1_000_000_000_000},
        "outage_minutes": {"units": {"minutes", "min"}, "minimum": 0, "maximum": 1440},
        "peak_demand": {"units": {"kw", "mw", "gw"}, "minimum": 0, "maximum": 1_000_000_000_000},
    },
}

class InfrastructureDataRegistry:
    def __init__(self) -> None:
        self._datasets: dict[str, dict[str, Any]] = {}

    def import_dataset(self, request: InfrastructureImportRequest) -> dict[str, Any]:
        rules = METRIC_RULES[request.domain]
        issues: list[dict[str, Any]] = []
        seen: set[tuple[str, str, str]] = set()
        counts: Counter[str] = Counter()
        values: dict[str, list[float]] = {}
        normalized = []
        for index, observation in enumerate(request.observations):
            metric = observation.metric.lower().strip()
            rule = rules.get(metric)
            if rule is None:
                issues.append({"row": index + 1, "code": "unsupported_metric", "message": f"Metric '{observation.metric}' is not supported for {request.domain}."})
                continue
            unit = observation.unit.lower().strip()
            if unit not in rule["units"]:
                issues.append({"row": index + 1, "code": "unit_mismatch", "message": f"Unit '{observation.unit}' is not accepted for metric '{metric}'."})
                continue
            if not isfinite(observation.value) or not rule["minimum"] <= observation.value <= rule["maximum"]:
                issues.append({"row": index + 1, "code": "out_of_range", "message": f"Value for '{metric}' is outside the accepted sanity range."})
                continue
            stamp = observation.observed_at
            if stamp.tzinfo is None:
                issues.append({"row": index + 1, "code": "timezone_missing", "message": "Observation timestamp must include a timezone."})
                continue
            key = (stamp.isoformat(), observation.area.casefold(), metric)
            if key in seen:
                issues.append({"row": index + 1, "code": "duplicate_observation", "message": "Duplicate timestamp, area and metric combination."})
                continue
            seen.add(key)
            counts[metric] += 1
            values.setdefault(metric, []).append(observation.value)
            normalized.append({"observed_at": stamp.isoformat(), "area": observation.area, "metric": metric, "value": observation.value, "unit": observation.unit})

        if not normalized:
            raise ValueError("No valid observations remain after quality checks.")
        if request.data_as_of > datetime.now(timezone.utc).date():
            issues.append({"row": None, "code": "future_data_as_of", "message": "Dataset 'data as of' date is in the future."})
        if request.data_as_of < max(o.observed_at.date() for o in request.observations):
            issues.append({"row": None, "code": "date_metadata_mismatch", "message": "Some observation dates are later than the declared data-as-of date."})

        summaries = {
            metric: {"count": len(items), "minimum": min(items), "maximum": max(items), "mean": round(sum(items) / len(items), 4)}
            for metric, items in values.items()
        }
        record = {
            "dataset_id": str(uuid4()), "domain": request.domain,
            "dataset_name": request.dataset_name, "provider": request.provider,
            "source_url": str(request.source_url), "license": request.license,
            "data_as_of": request.data_as_of.isoformat(),
            "imported_at": datetime.now(timezone.utc).isoformat(),
            "observation_count": len(normalized), "rejected_count": len(request.observations) - len(normalized),
            "quality_status": "review_required" if issues else "basic_checks_passed",
            "quality_issues": issues, "metric_summaries": summaries,
            "observations": normalized,
            "integration_note": "User-supplied data. Metadata and sanity checks do not independently verify the provider, license, accuracy or completeness. Not connected to simulation outputs.",
        }
        self._datasets[record["dataset_id"]] = record
        return self._public(record)

    @staticmethod
    def _public(record: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in record.items() if key != "observations"}

    def list_datasets(self, domain: str | None = None) -> dict[str, Any]:
        records = [self._public(item) for item in self._datasets.values() if domain is None or item["domain"] == domain]
        return {"datasets": records, "count": len(records), "storage": "in_memory_until_api_process_restarts", "note": "Imported records remain separate from synthetic city calculations."}

    def get_dataset(self, dataset_id: str) -> dict[str, Any] | None:
        return self._datasets.get(dataset_id)

registry = InfrastructureDataRegistry()
