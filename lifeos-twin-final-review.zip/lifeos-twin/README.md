# LifeOS Twin

**A city-planning decision-support prototype with a 3D interface, scenario simulation, evidence retrieval and rule-based specialist analysis.**

LifeOS Twin models a fictional city called Nova City. Users can inspect districts, change planning assumptions, compare possible interventions and review how traffic, water demand and electricity demand respond. The project is designed to make assumptions, calculations and limitations visible.

> **Project status:** Experimental prototype. The city and its infrastructure indicators are synthetic. This is not a live city digital twin, a validated forecasting system or an infrastructure control platform.

## Main capabilities

- **3D city interface:** Browser-based district view built with Three.js.
- **Scenario simulation:** Python calculations for traffic, water demand and electricity demand.
- **What-if comparison:** Compare 2–6 options for one district, including population growth, commercial growth and green-space changes.
- **Decision support:** Rank four intervention options using a transparent weighted-impact heuristic and show trade-offs.
- **Specialist review:** Three deterministic domain specialists (traffic, water and electricity) score options independently and produce a traceable vote, dissent and consensus summary.
- **Forecast exploration:** Project scenario values over 1–10 years using user-supplied annual growth assumptions. This is compound-growth arithmetic, not a trained predictive model.
- **Knowledge retrieval:** Search a built-in synthetic planning corpus using BM25 and TF-IDF retrieval. Optional neural retrieval and local Ollama text generation are disabled unless configured.
- **Private workspaces:** Account registration, bearer-token authentication, SQLite-backed scenarios, notes and private investigation memory.
- **External context:** Optional Open-Meteo current-weather lookup. Weather is displayed separately and does not modify infrastructure calculations.
- **Infrastructure data intake:** Import user-supplied traffic, water or electricity observations with basic metric, unit, timestamp and range checks. Imported observations are currently in-memory only and are not used by the simulator.
- **Reports and audit details:** PDF scenario and investigation reports, verification checks, task traces and input fingerprints.

## Architecture

```text
Browser UI (HTML / CSS / JavaScript / Three.js)
                  |
              FastAPI API
                  |
    +-------------+----------------+
    |             |                |
Simulation    Knowledge &      Agent workflow
engine        retrieval         and verification
    |             |                |
Synthetic     Synthetic corpus  Rule-based planner,
city model    + private notes   task handlers, specialists
                  |
             SQLite workspaces
```

The planner, task executor and specialist agents are deterministic Python components. They do not autonomously plan with an LLM. Numeric outputs come from Python simulation functions. The optional local language model can only draft explanatory text from prepared results; it is not required to run the core project.

## Run locally

Requirements: Python 3.11 or newer and a modern browser with WebGL support.

1. Open a terminal in `backend/`.
2. Create and activate a Python environment if desired.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the API:

   ```bash
   uvicorn app.main:app --reload
   ```

5. Open `frontend/index.html` in a browser. The default API address is `http://127.0.0.1:8000`.

The frontend loads Three.js from jsDelivr, so the 3D library needs an internet connection. The static city view can load independently; API-backed features require the backend to be running.

API documentation is available at `http://127.0.0.1:8000/docs` while the backend is running.

## Configuration and deployment warning

Copy `backend/.env.example` to `backend/.env` only if you need optional configuration. Before any public deployment:

- Set `LIFEOS_AUTH_SECRET` to a unique, long random value.
- Set `LIFEOS_CORS_ORIGINS` to the exact frontend origin(s); do not use `*`.
- Use HTTPS and a managed persistent database/storage strategy.
- Review authentication, rate limits, request limits, logging and privacy controls.
- Host the Python API separately. GitHub Pages can host only the static frontend; it does not run FastAPI.

This repository has a GitHub Pages workflow for the frontend, but the project has **not** been deployed as part of this deliverable.

## Validation

Run backend tests from `backend/`:

```bash
pytest -q
```

The current project suite contains **120 passing backend tests**. These tests cover API behavior and deterministic logic; they do not constitute browser visual testing, a production security audit, real-world model validation or a live Open-Meteo availability guarantee.

## Known limitations

- Nova City, its districts and infrastructure baselines are synthetic.
- Decision scores are prototype heuristics, not probabilities or engineering recommendations.
- Specialist debate is deterministic rule-based analysis, not independent human or LLM reasoning.
- Forecasts apply user-entered compound growth rates; no historical training data is used.
- Open-Meteo weather is contextual only and is not connected to traffic, water or electricity calculations.
- Imported infrastructure datasets are user supplied, receive basic validation only, are held in memory until the API restarts, and are not connected to the simulation engine.
- The frontend has not had a formal cross-browser or accessibility audit.
- The application is not ready for production or real municipal decision-making.

## Project documentation

- [System architecture](docs/architecture.md)
- [Knowledge engine](docs/knowledge-engine.md)
- [Private workspaces and authentication](docs/authentication-and-workspaces.md)
- [Decision intelligence](docs/decision-intelligence.md)
- [Specialist debate](docs/multi-agent-debate.md)
- [Scenario exploration](docs/scenario-intelligence.md)
- [Forecasting assumptions](docs/predictive-forecasting.md)
- [External data integration](docs/external-data-integration.md)
- [Infrastructure data ingestion](docs/infrastructure-data-ingestion.md)
- [Investigation audit and PDF export](docs/investigation-audit-export.md)
- [Resume-ready project summary](docs/resume-description.md)
